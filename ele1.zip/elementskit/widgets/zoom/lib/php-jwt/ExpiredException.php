<?php
namespace ElementsKit\Firebase\JWT;

class ExpiredException extends \UnexpectedValueException
{
}
