<?php
namespace ElementsKit\Firebase\JWT;

class BeforeValidException extends \UnexpectedValueException
{
}
